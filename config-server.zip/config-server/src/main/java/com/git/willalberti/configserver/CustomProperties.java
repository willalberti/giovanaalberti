package com.git.willalberti.configserver;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;

@Getter
@ConfigurationProperties("custom-properties")
public class CustomProperties {
	private String name;
	private String value1;
}
